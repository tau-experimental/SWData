################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../main.c \
../rx.c \
../tx.c \
../wav_io.c 

C_DEPS += \
./main.d \
./rx.d \
./tx.d \
./wav_io.d 

OBJS += \
./main.o \
./rx.o \
./tx.o \
./wav_io.o 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GCC C Compiler'
	gcc -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean--2e-

clean--2e-:
	-$(RM) ./main.d ./main.o ./rx.d ./rx.o ./tx.d ./tx.o ./wav_io.d ./wav_io.o

.PHONY: clean--2e-

