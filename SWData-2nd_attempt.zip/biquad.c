#include "biquad.h"

void biquad_init(biquad_cell_t *f, float b0, float b1, float b2, float a1, float a2) {
    f->b0 = b0; f->b1 = b1; f->b2 = b2;
    f->a1 = a1; f->a2 = a2;
    f->w1 = 0.0f; f->w2 = 0.0f;
}

float biquad_process(biquad_cell_t *f, float input) {
    /* Реализация Direct Form II */
    float w0 = input - (f->a1 * f->w1) - (f->a2 * f->w2);
    float output = (f->b0 * w0) + (f->b1 * f->w1) + (f->b2 * f->w2);

    f->w2 = f->w1;
    f->w1 = w0;

    return output;
}

cplx_t iq_filter_process(iq_filter_t *filter, cplx_t input) {
    cplx_t output;
    output.r = biquad_process(&filter->filter_i, input.r);
    output.i = biquad_process(&filter->filter_q, input.i);
    return output;
}
