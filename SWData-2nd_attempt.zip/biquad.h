#ifndef BIQUAD_H
#define BIQUAD_H

#include "dsp_math.h"

/* Контекст одного канала Biquad-фильтра Direct Form II (24 байта) */
typedef struct {
    float b0, b1, b2; /* Коэффициенты прямого пути */
    float a1, a2;     /* Коэффициенты обратной связи */
    float w1, w2;     /* Состояние памяти фильтра (ячейки задержки) */
} biquad_cell_t;

/* Объединенный контекст для фильтрации комплексного I/Q потока */
typedef struct {
    biquad_cell_t filter_i;
    biquad_cell_t filter_q;
} iq_filter_t;

/* Инициализация коэффициентов фильтра полосового пропускания */
void biquad_init(biquad_cell_t *f, float b0, float b1, float b2, float a1, float a2);

/* Обработка одного отсчета (атомарная операция) */
float biquad_process(biquad_cell_t *f, float input);

/* Комплексная фильтрация отсчета I/Q */
cplx_t iq_filter_process(iq_filter_t *filter, cplx_t input);

#endif /* BIQUAD_H */
