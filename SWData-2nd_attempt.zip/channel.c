#include "channel.h"
#include <math.h>

#define CH_TWO_PI 6.28318530f

static float channel_randf(uint32_t *seed) {
    *seed = (*seed * 1103515245ULL + 12345ULL) & 0x7FFFFFFF;
    return (float)(*seed) / 2147483647.0f;
}

void channel_init(kv_channel_t *ch, uint32_t seed, float fading_hz) {
    ch->seed = seed;
    ch->brown_state_i = 0.0f;
    ch->brown_state_q = 0.0f;
    ch->history_idx = 0;
    ch->fading_phase = 0.0f;
    ch->fading_speed = (CH_TWO_PI * fading_hz) / 8000.0f; /* 8000 = Fs */

    for (int i = 0; i < MAX_PATH_DELAY_SAMPLES; i++) {
        ch->history[i].r = 0.0f;
        ch->history[i].i = 0.0f;
    }
}

cplx_t channel_add_awgn(kv_channel_t *ch, cplx_t in, float snr_db) {
    float u1 = channel_randf(&ch->seed) + 1e-7f;
    float u2 = channel_randf(&ch->seed);

    float r = sqrtf(-2.0f * logf(u1));
    float theta = CH_TWO_PI * u2;

    float snr_linear = powf(10.0f, snr_db / 10.0f);
    float sigma = sqrtf(0.5f / snr_linear) * 0.7071f; /* Комплексное деление мощности */

    cplx_t out;
    out.r = in.r + r * cosf(theta) * sigma;
    out.i = in.i + r * sinf(theta) * sigma;
    return out;
}

cplx_t channel_add_brownian(kv_channel_t *ch, cplx_t in, float level) {
    /* Коричневый шум получается путем интегрирования белого шума (Random Walk) */
    float ni = (channel_randf(&ch->seed) - 0.5f) * level;
    float nq = (channel_randf(&ch->seed) - 0.5f) * level;

    /* Простейший утекающий интегратор (Leaky Integrator) во избежание бесконечного дрейфа */
    ch->brown_state_i = ch->brown_state_i * 0.99f + ni;
    ch->brown_state_q = ch->brown_state_q * 0.99f + nq;

    cplx_t out;
    out.r = in.r + ch->brown_state_i;
    out.i = in.i + ch->brown_state_q;
    return out;
}

cplx_t channel_add_clicks(kv_channel_t *ch, cplx_t in, float probability, float max_amplitude) {
    cplx_t out = in;
    if (channel_randf(&ch->seed) < probability) {
        /* Генерируем мощный кратковременный щелчок (импульс) */
        float angle = channel_randf(&ch->seed) * CH_TWO_PI;
        float amp = channel_randf(&ch->seed) * max_amplitude;
        out.r += amp * cosf(angle);
        out.i += amp * sinf(angle);
    }
    return out;
}

cplx_t channel_process_multipath(kv_channel_t *ch, cplx_t in, const kv_path_t *paths, int path_count) {
    /* Сохраняем текущий отсчет в линию задержки (кольцевой буфер) */
    ch->history[ch->history_idx] = in;

    cplx_t out = {0.0f, 0.0f};

    /* Моделируем замирания (Мультипликативный фединг Райса/Релея через вращение вектора замираний) */
    ch->fading_phase += ch->fading_speed;
    if (ch->fading_phase >= CH_TWO_PI) ch->fading_phase -= CH_TWO_PI;

    float fade_factor_r = cosf(ch->fading_phase);
    float fade_factor_i = sinf(ch->fading_phase);

    for (int i = 0; i < path_count; i++) {
        int lookback = ch->history_idx - paths[i].delay_samples;
        if (lookback < 0) lookback += MAX_PATH_DELAY_SAMPLES;

        cplx_t delayed_sample = ch->history[lookback];

        /* Применяем фазовый сдвиг луча и затухание */
        float total_phase = paths[i].phase_shift;
        float cos_p = cosf(total_phase);
        float sin_p = sinf(total_phase);

        cplx_t path_signal;
        path_signal.r = (delayed_sample.r * cos_p - delayed_sample.i * sin_p) * paths[i].attenuation;
        path_signal.i = (delayed_sample.r * sin_p + delayed_sample.i * cos_p) * paths[i].attenuation;

        /* Для вторичных лучей подмешиваем влияние динамического фединга (Допплеровское размытие) */
        if (i > 0) {
            float r_tmp = path_signal.r * fade_factor_r - path_signal.i * fade_factor_i;
            path_signal.i = path_signal.r * fade_factor_i + path_signal.i * fade_factor_r;
            path_signal.r = r_tmp;
        }

        out.r += path_signal.r;
        out.i += path_signal.i;
    }

    ch->history_idx = (ch->history_idx + 1) % MAX_PATH_DELAY_SAMPLES;
    return out;
}
