#ifndef CHANNEL_H
#define CHANNEL_H

#include "dsp_math.h"
#include <stdint.h>

#define MAX_PATH_DELAY_SAMPLES 32 /* Максимальная задержка луча (~4 мс при 8кГц) */

/* Структура для имитации одного луча в КВ-канале */
typedef struct {
    float attenuation;   /* Ослабление луча (0.0 ... 1.0) */
    int delay_samples;   /* Задержка луча в отсчетах */
    float phase_shift;   /* Постоянный набег фазы в луче (радианы) */
} kv_path_t;

/* Контекст имитатора канала (Хранится в стеке или статически, памяти < 512 байт) */
typedef struct {
    uint32_t seed;
    float brown_state_i; /* Память для формирования коричневого шума */
    float brown_state_q;

    /* Буфер задержки для многолучевого распространения */
    cplx_t history[MAX_PATH_DELAY_SAMPLES];
    int history_idx;

    /* Параметры медленного фединга */
    float fading_phase;
    float fading_speed;  /* Скорость изменения замираний (влияние Авроры) */
} kv_channel_t;

void channel_init(kv_channel_t *ch, uint32_t seed, float fading_hz);

/* Добавление белого шума (AWGN) */
cplx_t channel_add_awgn(kv_channel_t *ch, cplx_t in, float snr_db);

/* Добавление коричневого (интегрального) шума с завалом высоких частот */
cplx_t channel_add_brownian(kv_channel_t *ch, cplx_t in, float level);

/* Имитация апериодических широкополосных щелчков (атмосферные разряды / грозы) */
cplx_t channel_add_clicks(kv_channel_t *ch, cplx_t in, float probability, float max_amplitude);

/* Пропуск сигнала через модель многолучевого распространения с федингом */
cplx_t channel_process_multipath(kv_channel_t *ch, cplx_t in, const kv_path_t *paths, int path_count);

#endif /* CHANNEL_H */
