#include "detector.h"
#include <math.h>
#include <stdio.h>

#define ALPHA_CLOCK         0.98f     /* Коэффициент памяти для тактового буфера */
#define PLL_KP              0.02f     /* Пропорциональный коэффициент ФАПЧ */
#define PLL_KI              0.002f    /* Интегральный коэффициент ФАПЧ */
#define M_PI_F              3.14159265f

void detector_init(phase_detector_t *det) {
    det->sample_counter = 0;
    det->symbol_boundary_idx = 0; /* Жесткий ноль для теста */
    det->total_samples_processed = 0;
    det->symbols_accumulated = 0;

    det->pll_phase = 0.0f;
    det->pll_freq_error = 0.0f;

    det->integrity_0 = (cplx_t){0.0f, 0.0f};
    det->integrity_plus = (cplx_t){0.0f, 0.0f};
    det->integrity_minus = (cplx_t){0.0f, 0.0f};

    det->integrity_early = (cplx_t){0.0f, 0.0f};
    det->integrity_late = (cplx_t){0.0f, 0.0f};

    det->prev_symbol_vector = (cplx_t){1.0f, 0.0f};

    //det->state = FSM_STATE_SEARCH;
    //det->is_synced = 0;
    det->state = FSM_STATE_ENERGY_DETECT;
	det->is_synced = 0;
	det->sample_period_fraction = 0.0f;

    for (int i = 0; i < DET_SAMPLES_PER_SYM; i++) {
        det->energy_buffer[i] = 0.0f;
    }

    dds_init(&det->local_oscillator, 1000.0f, 0.0f);

    /* Открываем файл отладки, привязывая его к контексту */
    det->csv_log = fopen("corr_waterfall.csv", "w");
    if (det->csv_log) {
        fprintf(det->csv_log, "SampleIdx,");
        for (int ch = 0; ch < NUM_FREQ_CHANNELS; ch++) {
            fprintf(det->csv_log, "F_%dHz%c", 990 + ch * 2, (ch == NUM_FREQ_CHANNELS - 1) ? '\n' : ',');
        }
    }
}

/* Внутренняя функция поиска минимума огибающей (границы символа) */
static void update_clock_sync(phase_detector_t *det) {
    float min_energy = det->energy_buffer[0];
    int min_idx = 0;

    for (int i = 1; i < DET_SAMPLES_PER_SYM; i++) {
        if (det->energy_buffer[i] < min_energy) {
            min_energy = det->energy_buffer[i];
            min_idx = i;
        }
    }
    det->symbol_boundary_idx = min_idx;
}

#include "detector.h"
#include <math.h>
#include <stdio.h>

#define COHERENT_INTEGRATION_LEN  6400      /* Длина статистического накопления (4 символа) */
#define COHERENCE_THRESHOLD       0.15f     /* Порог когерентности (0.0 - шум, 1.0 - идеальный тон) */

#include "detector.h"
#include <math.h>
#include <stdio.h>

#define NUM_FREQ_CHANNELS   3
#define DET_MAG_THRESHOLD   15.0f /* Порог превышения корреляции над шумом */

#include "detector.h"
#include <math.h>
#include <stdio.h>

#define NUM_FREQ_CHANNELS   11
#define M_PI_F              3.14159265f

int detector_process_sample(phase_detector_t *det, cplx_t sample) {
    int decision = 0;
    det->total_samples_processed++;

    det->sample_counter++;
    if (det->sample_counter >= DET_SAMPLES_PER_SYM) {
        det->sample_counter = 0;
    }

    /* Гребенка из 11 каналов коррелятора */
    static float lo_phases[NUM_FREQ_CHANNELS] = {0};
    static float lo_steps[NUM_FREQ_CHANNELS] = {0};
    static int lo_initialized = 0;

    if (!lo_initialized) {
        for (int ch = 0; ch < NUM_FREQ_CHANNELS; ch++) {
            float freq = 990.0f + (float)ch * 2.0f;
            lo_steps[ch] = (2.0f * M_PI_F * freq) / DET_FS;
        }
        lo_initialized = 1;
    }

    static cplx_t corr_accumulators[NUM_FREQ_CHANNELS] = {0};

    for (int ch = 0; ch < NUM_FREQ_CHANNELS; ch++) {
        float cos_lo = cosf(-lo_phases[ch]);
        float sin_lo = sinf(-lo_phases[ch]);

        /* Комплексное накопление свёртки */
        corr_accumulators[ch].r += (sample.r * cos_lo - sample.i * sin_lo);
        corr_accumulators[ch].i += (sample.r * sin_lo + sample.i * cos_lo);

        lo_phases[ch] += lo_steps[ch];
        if (lo_phases[ch] >= 2.0f * M_PI_F) lo_phases[ch] -= 2.0f * M_PI_F;
    }

    /* БЕЗОПАСНАЯ НЕПРЕРЫВНАЯ ЗАПИСЬ НА КАЖДОМ ОТСЧЕТЕ */
    if ((det->csv_log) && ((det->sample_counter % 16) == 0)) {
        fprintf(det->csv_log, "%u,", det->total_samples_processed);
        for (int ch = 0; ch < NUM_FREQ_CHANNELS; ch++) {
            float r = corr_accumulators[ch].r;
            float i = corr_accumulators[ch].i;
            float current_power = (r * r) + (i * i);

            /* Убираем деление на 100, пишем честную мощность */
            fprintf(det->csv_log, "%.2f%c", current_power, (ch == NUM_FREQ_CHANNELS - 1) ? '\n' : ',');
        }
    }

    /* Консольный срез раз в символ (1600 сэмплов) */
    if (det->sample_counter == 0) {
        float total_comb_power = 0.0f;

        /* Складываем энергию ВСЕХ 11 каналов (Паранойя: нам не важен уплыв частоты float) */
        for (int ch = 0; ch < NUM_FREQ_CHANNELS; ch++) {
            float r = corr_accumulators[ch].r;
            float i = corr_accumulators[ch].i;
            total_comb_power += (r * r) + (i * i);
        }

        /* Масштабируем для проверки */
        total_comb_power /= 100.0f;

        printf("[FSM SEARCH] Интеграл символа %2d | Суммарная когерентная энергия гребёнки: %7.1f\n",
               det->symbols_accumulated, total_comb_power);

        /* Если суммарный отклик гребёнки корреляторов пробивает порог шума (для чистого сигнала это > 5.0) */
        if (total_comb_power > 10.0f) {
            det->state = FSM_STATE_SYNC_SEARCH;
            printf("[FSM] ЭТАП 1: Сигнал стопроцентно ОБНАРУЖЕН по гребёнке корреляторов! Переход к поиску шва.\n");
        }
    }

    return decision;
}
