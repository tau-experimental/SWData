#ifndef DETECTOR_H
#define DETECTOR_H

#include "generator.h"
#include "dsp_math.h"
#include <stdint.h>
#include <stdio.h>

#define DET_FS               8000.0f
#define DET_BAUD             5.0f
#define DET_SAMPLES_PER_SYM  ((int)(DET_FS / DET_BAUD)) /* 1600 */
#define DLL_TAU             80        /* Сдвиг окон Early/Late (5% от длины символа) */
#define DLL_GAIN            0.05f     /* Коэффициент подстройки тактовой петли */
#define M_PI_F              3.14159265f

#define NUM_FREQ_CHANNELS   11

/* Состояния конечного автомата (FSM) детектора */
typedef enum {
    FSM_STATE_SEARCH = 0,    /* Поиск тактовой синхронизации (ожидание накопления) */
	FSM_STATE_ENERGY_DETECT,
	FSM_STATE_SYNC_SEARCH,
    FSM_STATE_TRACKING,      /* Синхронизация удержана, декодирование фазы */
    FSM_STATE_LOSS           /* Потеря сигнала */
} det_fsm_state_t;

/* Структура детектора (Помещается в < 8 КБ RAM) */
typedef struct {
    /* --- Блок тактовой синхронизации (Early-Late) --- */
    float energy_buffer[DET_SAMPLES_PER_SYM]; /* Кольцевой буфер профиля символа (6.4 КБ) */
    int sample_counter;                        /* Счетчик отсчетов внутри текущего символа */
    int symbol_boundary_idx;                   /* Обнаруженный индекс границы символа */
    uint32_t total_samples_processed;          /* Глобальный счетчик для логов */
    int is_synced;                             /* Флаг успешной синхронизации */
    uint32_t symbols_accumulated;              /* Сколько символов профильтровано в буфер */

    /* --- Блок ФАПЧ (Частотная коррекция) --- */
    float pll_phase;                           /* Текущая фаза локального гетеродина ФАПЧ */
    float pll_freq_error;                      /* Накопленная ошибка частоты */

    /* --- Когерентные интеграторы (3 Гипотезы) --- */
    cplx_t integrity_0;                        /* Накопление для гипотезы 0 градусов */
    cplx_t integrity_plus;                     /* Накопление для гипотезы +120 градусов */
    cplx_t integrity_minus;                    /* Накопление для гипотезы -120 градусов */
    cplx_t prev_symbol_vector;                 /* Опорный вектор предыдущего символа */

    /* Early-Late (Delay-Locked Loop — DLL) */
    cplx_t integrity_early;
    cplx_t integrity_late;
    float sample_period_fraction;

    /* --- Конечный автомат (FSM) --- */
    det_fsm_state_t state;

    dds_lut_t local_oscillator; /* Локальный гетеродин приёмника на 1000 Гц */

    FILE *csv_log;
} phase_detector_t;

/* Инициализация детектора */
void detector_init(phase_detector_t *det);

/* Потоковая обработка одного отсчета I/Q.                      */
/* Возвращает: 1 при обнаружении "+120" (Вперед),               */
/*            -1 при обнаружении "-120" (Назад),                */
/*             0 в остальных случаях (нет смены/идет накопление).*/
int detector_process_sample(phase_detector_t *det, cplx_t sample);

#endif /* DETECTOR_H */
