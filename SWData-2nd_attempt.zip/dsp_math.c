#include "dsp_math.h"

#define DSP_PI          3.14159265f
#define DSP_COS_120     -0.5f
#define DSP_SIN_120     0.86602540f

/* Использование аппроксимации знака и полинома для экономии тактов MCU */
float dsp_atan2f(float y, float x) {
    /* Оптимизированный алгоритм atan2 с плавающей точкой (ошибка менее 0.05 град) */
    float abs_y = (y < 0.0f) ? -y : y;
    float abs_x = (x < 0.0f) ? -x : x;
    float angle;

    if (abs_x == 0.0f && abs_y == 0.0f) {
        return 0.0f;
    }

    if (abs_x >= abs_y) {
        float r = y / x;
        /* Полином Чебышева первой степени для atan(r) */
        angle = r / (1.0f + 0.28086f * r * r);
        if (x < 0.0f) {
            if (y >= 0.0f) angle += DSP_PI;
            else angle -= DSP_PI;
        }
    } else {
        float r = x / y;
        angle = r / (1.0f + 0.28086f * r * r);
        if (y < 0.0f) angle = -DSP_PI / 2.0f - angle;
        else angle = DSP_PI / 2.0f - angle;
        if (x < 0.0f) {
            if (y < 0.0f) angle -= 0.0f; /* Коррекция квадранта */
        }
    }
    return angle;
}

float dsp_cplx_dot(cplx_t a, cplx_t b) {
    return (a.r * b.r) + (a.i * b.i);
}

float dsp_cplx_cross(cplx_t a, cplx_t b) {
    return (a.i * b.r) - (a.r * b.i);
}

cplx_t dsp_cplx_rotate120(cplx_t v, int forward) {
    cplx_t res;
    /* cos(120) = -0.5, sin(120) = ~0.866 */
    float sin_val = forward ? DSP_SIN_120 : -DSP_SIN_120;

    res.r = v.r * DSP_COS_120 - v.i * sin_val;
    res.i = v.r * sin_val + v.i * DSP_COS_120;
    return res;
}
