#ifndef DSP_MATH_H
#define DSP_MATH_H

/* Компактная структура комплексного числа (8 байт) */
typedef struct {
    float r; /* Real part */
    float i; /* Imaginary part */
} cplx_t;

/* Быстрое приближение угла вектора (аппроксимация atan2) */
/* Возвращает угол в радианах от -PI до PI */
float dsp_atan2f(float y, float x);

/* Скалярное произведение двух комплексных чисел: Re(A * conj(B)) */
float dsp_cplx_dot(cplx_t a, cplx_t b);

/* Векторное (псевдоскалярное) произведение: Im(A * conj(B)) */
float dsp_cplx_cross(cplx_t a, cplx_t b);

/* Поворот вектора на фиксированный угол (+120 или -120 градусов) */
/* Ускоренная версия без вызова sin/cos (константы зашиты внутри) */
cplx_t dsp_cplx_rotate120(cplx_t v, int forward);

#endif /* DSP_MATH_H */
