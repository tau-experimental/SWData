#include "generator.h"
#include <math.h>

#define M_PI_F 3.14159265f

void dds_init(dds_lut_t *dds, float freq, float offset) {
    /* Заполняем таблицу синуса для полного периода */
    for (int i = 0; i < DDS_LUT_SIZE; i++) {
        dds->lut[i] = sinf(((float)i * 2.0f * M_PI_F) / (float)DDS_LUT_SIZE);
    }
    dds->phase_accumulator = 0;

    /* Расчет шага фазы для 32-битного аккумулятора: step = (F_sig / F_s) * 2^32 */
    double target_freq = (double)(freq + offset);
    double step = (target_freq / (double)MOD_FS) * 4294967296.0;
    dds->phase_step = (uint32_t)step;
}

cplx_t dds_next_sample(dds_lut_t *dds) {
    cplx_t out;

    /* Индекс для Синуса (Q) */
    uint32_t idx_sin = (dds->phase_accumulator >> (32 - 9)) & DDS_LUT_MASK; /* 9 бит для размера 512 */

    /* Индекс для Косинуса (I) — сдвиг на 90 градусов (четверть таблицы = 128 элементов) */
    uint32_t idx_cos = (idx_sin + 128) & DDS_LUT_MASK;

    out.r = dds->lut[idx_cos]; /* I компонент */
    out.i = dds->lut[idx_sin]; /* Q компонент */

    /* Продвигаем аккумулятор */
    dds->phase_accumulator += dds->phase_step;

    return out;
}

void dds_shift_phase(dds_lut_t *dds, float angle_deg) {
    /* Переводим угол в эквивалент для 32-битного аккумулятора */
    float fraction = angle_deg / 360.0f;
    int32_t phase_shift = (int32_t)(fraction * 4294967296.0f);
    dds->phase_accumulator += phase_shift;
}
