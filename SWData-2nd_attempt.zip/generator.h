#ifndef GENERATOR_H
#define GENERATOR_H

#include "dsp_math.h"
#include <stdint.h>

#define MOD_FS              8000.0f
#define MOD_BAUD            5.0f
#define MOD_SAMPLES_PER_SYM ((int)(MOD_FS / MOD_BAUD)) /* 1600 отсчетов */
#define DDS_LUT_SIZE        512
#define DDS_LUT_MASK        (DDS_LUT_SIZE - 1)

/* Состояние табличного DDS генератора */
typedef struct {
    uint32_t phase_accumulator; /* 32-битный аккумулятор фазы */
    uint32_t phase_step;        /* Шаг фазы для заданной частоты */
    float lut[DDS_LUT_SIZE];    /* Таблица синуса (одна четверть или полный период) */
} dds_lut_t;

/* Общая структура конфигурации тестового сценария */
typedef struct {
    float carrier_freq;      /* Центральная несущая (например, 1000 Гц) */
    float freq_offset;       /* Смещение/расстройка частоты (например, +3 Гц) */
    uint32_t silence_pre_ms; /* Длительность тишины/шума ДО сигнала в мс */
    uint32_t silence_post_ms;/* Длительность тишины/шума ПОСЛЕ сигнала в мс */
} gen_config_t;

/* Инициализация таблицы синуса и шага фазы */
void dds_init(dds_lut_t *dds, float freq, float offset);

/* Получение следующего чистого отсчета (амплитуда 1.0) */
cplx_t dds_next_sample(dds_lut_t *dds);

/* Сдвиг текущей фазы DDS на заданный угол в градусах (+120 / -120) */
void dds_shift_phase(dds_lut_t *dds, float angle_deg);

#endif /* GENERATOR_H */
