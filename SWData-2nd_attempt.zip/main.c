#include <stdio.h>
#include "biquad.h"
#include "detector.h"
#include "wav_io.h"

void run_receiver_with_dumps(const char* input_wav, const char* filtered_wav, const char* pll_wav) {
    printf("\n--- ЗАПУСК ДЕМОДУЛЯТОРА: %s ---\n", input_wav);

    FILE *f_in = fopen(input_wav, "rb");
    if (!f_in) {
        printf("Не удалось открыть входной файл: %s\n", input_wav);
        return;
    }

    /* Пропускаем 44 байта заголовка */
    fseek(f_in, 44, SEEK_SET);

    /* Открываем файлы для аудиовизуального контроля в Audacity */
    wav_writer_t writer_filt;
    wav_writer_t writer_pll;
    wav_writer_open(&writer_filt, filtered_wav, 8000);
    wav_writer_open(&writer_pll, pll_wav, 8000);

    /* Инициализация ЦОС */
    iq_filter_t filter;
    /* Коэффициенты простейшего полосового фильтра около 1000 Гц */
    biquad_init(&filter.filter_i, 0.009593f, 0.000000f, -0.009593f, -1.400646f, 0.980813f);
    biquad_init(&filter.filter_q, 0.009593f, 0.000000f, -0.009593f, -1.400646f, 0.980813f);

    phase_detector_t detector;
    detector_init(&detector);

    /* ИСПРАВЛЕНО: Теперь это массив из двух элементов для I и Q */
    int16_t buffer[2];
    uint32_t sample_idx = 0;
    int decisions_count = 0;

    while (fread(buffer, sizeof(int16_t), 2, f_in) == 2) {
        cplx_t input;
        input.r = (float)buffer[1] / 32767.0f; /* каналы поменяны местами: Правый - I, левый - Q */
        input.i = (float)buffer[0] / 32767.0f;

        /* Шаг 1: Полосовая фильтрация */
        cplx_t filtered = iq_filter_process(&filter, input);

        /* Сбрасываем результат фильтрации на диск для Audacity */
        wav_writer_write_sample(&writer_filt, filtered);

        /* ФАПЧ и детектор пока работают "вхолостую" для удержания структуры */
        int result = detector_process_sample(&detector, filtered);

        /* Дамп ФАПЧ пишем, но временно не анализируем */
        cplx_t pll_monitor = { filtered.r, detector.pll_freq_error * 100.0f };
        wav_writer_write_sample(&writer_pll, pll_monitor);

        sample_idx++;
    }

    fclose(f_in);
    wav_writer_close(&writer_filt);
    wav_writer_close(&writer_pll);

    printf("Обработка завершена. Всего отсчетов: %d. Распознано символов: %d\n", sample_idx, decisions_count);
    if (detector.csv_log != NULL) {
        fclose(detector.csv_log);
        detector.csv_log = NULL;
        printf("[DEBUG] CSV-лог водопада успешно закрыт. Сгенерировано 17600 строк.\n");
    }
}

int main(void) {
    /* Запускаем исправление ошибок и пишем отладочные треки */
    //run_receiver_with_dumps("lab_clean_5baud.wav", "filtered_clean.wav", "pll_track_clean.wav");
    run_receiver_with_dumps("kv_channel_dirty_5baud.wav", "filtered_dirty.wav", "pll_track_dirty.wav");
    return 0;
}
