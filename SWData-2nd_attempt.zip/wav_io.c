#include "wav_io.h"
#include <string.h>

int wav_writer_open(wav_writer_t *writer, const char *filename, uint32_t sample_rate) {
    writer->file = fopen(filename, "wb");
    if (!writer->file) return 0;

    writer->samples_written = 0;

    /* Заполнение заглушки заголовка */
    memcpy(writer->header.chunk_id, "RIFF", 4);
    writer->header.chunk_size = 36; /* Будет перезаписано при закрытии */
    memcpy(writer->header.format, "WAVE", 4);
    memcpy(writer->header.subchunk1_id, "fmt ", 4);
    writer->header.subchunk1_size = 16;
    writer->header.audio_format = 1; /* PCM */
    writer->header.num_channels = 2; /* Stereo (I/Q) */
    writer->header.sample_rate = sample_rate;
    writer->header.bits_per_sample = 16;
    writer->header.block_align = 2 * (16 / 8); /* 4 байта на отсчет */
    writer->header.byte_rate = sample_rate * writer->header.block_align;
    memcpy(writer->header.subchunk2_id, "data", 4);
    writer->header.subchunk2_size = 0; /* Будет перезаписано */

    /* Записываем пустой заголовок */
    fwrite(&writer->header, sizeof(wav_header_t), 1, writer->file);
    return 1;
}

void wav_writer_write_sample(wav_writer_t *writer, cplx_t sample) {
    if (!writer->file) return;

    /* Жесткое ограничение (clipping) диапазона [-1.0, 1.0] */
    if (sample.r > 1.0f) sample.r = 1.0f;
    if (sample.r < -1.0f) sample.r = -1.0f;
    if (sample.i > 1.0f) sample.i = 1.0f;
    if (sample.i < -1.0f) sample.i = -1.0f;

    /* Конвертация в signed 16-bit PCM */
    int16_t pcm_i = (int16_t)(sample.r * 32767.0f);
    int16_t pcm_q = (int16_t)(sample.i * 32767.0f);

    /* Запись в порядке: Левый (I), Правый (Q) */
    fwrite(&pcm_i, sizeof(int16_t), 1, writer->file);
    fwrite(&pcm_q, sizeof(int16_t), 1, writer->file);

    writer->samples_written++;
}

void wav_writer_close(wav_writer_t *writer) {
    if (!writer->file) return;

    uint32_t data_size = writer->samples_written * writer->header.block_align;
    writer->header.subchunk2_size = data_size;
    writer->header.chunk_size = 36 + data_size;

    /* Возвращаемся в начало файла и обновляем заголовок */
    fseek(writer->file, 0, SEEK_SET);
    fwrite(&writer->header, sizeof(wav_header_t), 1, writer->file);

    fclose(writer->file);
    writer->file = NULL;
}
