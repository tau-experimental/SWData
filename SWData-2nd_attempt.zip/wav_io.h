#ifndef WAV_IO_H
#define WAV_IO_H

#include <stdio.h>
#include <stdint.h>
#include "dsp_math.h"

/* Структура заголовка RIFF WAV (44 байта) */
#pragma pack(push, 1)
typedef struct {
    char     chunk_id[4];      /* "RIFF" */
    uint32_t chunk_size;      /* Размер файла - 8 байт */
    char     format[4];        /* "WAVE" */
    char     subchunk1_id[4];  /* "fmt " */
    uint32_t subchunk1_size;  /* 16 для PCM */
    uint16_t audio_format;    /* 1 для PCM */
    uint16_t num_channels;    /* 2 для Stereo */
    uint32_t sample_rate;     /* 8000 */
    uint32_t byte_rate;       /* sample_rate * num_channels * (bits_per_sample/8) */
    uint16_t block_align;     /* num_channels * (bits_per_sample/8) */
    uint16_t bits_per_sample; /* 16 */
    char     subchunk2_id[4];  /* "data" */
    uint32_t subchunk2_size;  /* Размер данных */
} wav_header_t;
#pragma pack(pop)

/* Контекст записи файла */
typedef struct {
    FILE *file;
    uint32_t samples_written;
    wav_header_t header;
} wav_writer_t;

/* Открытие файла на запись */
int wav_writer_open(wav_writer_t *writer, const char *filename, uint32_t sample_rate);

/* Запись одного I/Q отсчета (Масштабируется из float [-1.0, 1.0] в int16_t) */
void wav_writer_write_sample(wav_writer_t *writer, cplx_t sample);

/* Закрытие файла с перезаписью размеров в заголовке */
void wav_writer_close(wav_writer_t *writer);

#endif /* WAV_IO_H */
